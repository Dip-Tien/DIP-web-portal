const o="dxbl-popup-root",a="dxbl-window",p=a+"-root",d=a+"-dialog",s="dxbl-popup-portal";export{s as a,d as b,p as c,o as d,a as e};
